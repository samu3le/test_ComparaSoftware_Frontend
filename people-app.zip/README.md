# Comandos a ejecutar:

## Instalar dependencias

```bash
    nvm use
    npm i
    npm run lint
    npm run dev
```