<script setup></script>

<template>
  <main>Bienvenido a mi sitio web</main>
</template>
